Config = {}

Config.Shops = {
    {
        label = 'Dealer',
        coords = vector4(243.7314, 370.3529, 105.7381, 344.2580),
        pedModel = 'a_m_m_business_01',
        items = {
            {name = 'weed_processing_table', label = 'Pracovní stul weed', cost = 12460},
            {name = 'cocaine_processing_table', label = 'Pracovní stul koka', cost = 42560},
            {name = 'meth_processing_table', label = 'Pracovní stul meth', cost = 29780},
        },
        useOxTarget = true,  -- Set to true to use ox_target
        useOxLibTextUI = false  -- Set to true to use ox_lib TextUI
    },
    {
        label = 'Chemik',
        coords = vector4(234.5058, -1852.7406, 26.8393, 319.0182),
        pedModel = 'a_m_m_business_01',
        items = {
            {name = 'meth_amoniak', label = 'Ammoniak', cost = 150},
            {name = 'meth_pipe', label = 'Pipeta', cost = 30},
            {name = 'meth_syringe', label = 'Střýkačka', cost = 30},
            {name = 'meth_bag', label = 'Plastový sáček', cost = 15},
        },
        useOxTarget = true,  -- Set to true to use ox_target
        useOxLibTextUI = false  -- Set to true to use ox_lib TextUI
    }
}