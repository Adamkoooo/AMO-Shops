fx_version 'cerulean'
game 'gta5'
lua54 'yes'

author 'Adamkoo'
description 'Simple shops scripts'
version '1.3.3'

ui_page 'web/shop_ui.html'

shared_scripts {
    '@ox_lib/init.lua',
}

client_scripts {
    'client/client.lua',
    'config/config.lua'
}

server_scripts {
    'server/server.lua',
    'config/config.lua'
}

dependencies {
    'ox_lib'
}