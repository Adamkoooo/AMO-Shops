local function createShopMenu(shopIndex)
    local shop = Config.Shops[shopIndex]
    local options = {}

    for _, item in ipairs(shop.items) do
        table.insert(options, {
            title = item.label,
            description = 'Buy ' .. item.label .. ' for ' .. item.cost .. '$',
            onSelect = function()
                local input = lib.inputDialog('Enter quantity', {
                    { type = 'number', label = 'Quantity', default = 1, min = 1 }
                })

                if input and input[1] then
                    local quantity = input[1]
                    local totalCost = item.cost * quantity

                    if lib.progressBar({
                        duration = 2000,
                        label = 'Buying ' .. quantity .. 'x ' .. item.label .. '...',
                        useWhileDead = false,
                        canCancel = true,
                        disable = {
                            car = true,
                        },
                        disableMovement = true  -- Disable movement during progress
                    }) then
                        TriggerServerEvent('amo_buy:item', item.name, totalCost, quantity)
                    else
                        print('Purchase cancelled')
                    end
                else
                    print('Invalid quantity entered or cancelled')
                end
            end
        })
    end

    lib.registerContext({
        id = 'shop_menu_' .. shopIndex,
        title = shop.label or 'Shop',  -- Uses the name from `label` if provided, otherwise "Shop"
        options = options
    })
end

local function spawnShopNPC(shopIndex)
    local shop = Config.Shops[shopIndex]
    RequestModel(GetHashKey(shop.pedModel))

    while not HasModelLoaded(GetHashKey(shop.pedModel)) do
        Wait(1)
    end

    local ped = CreatePed(4, GetHashKey(shop.pedModel), shop.coords.x, shop.coords.y, shop.coords.z - 1.0, shop.heading, false, true)
    SetEntityAsMissionEntity(ped, true, true)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedDiesWhenInjured(ped, false)
    SetPedCanRagdollFromPlayerImpact(ped, false)
    SetPedCanRagdoll(ped, false)
    SetEntityInvincible(ped, true)
    FreezeEntityPosition(ped, true)

    -- Check configuration to use ox_target or ox_lib TextUI
    if shop.useOxTarget then
        exports.ox_target:addLocalEntity(ped, {
            {
                name = 'shop_' .. shopIndex,
                icon = 'fa-solid fa-shop',
                label = '' .. (shop.label or 'Shop'),  -- Displays, for example, "Open Albert" or "Open Shop"
                onSelect = function()
                    local playerPed = PlayerPedId()

                    -- Load animation dictionary
                    local animDict = 'mp_common'
                    local animName = 'givetake1_a'

                    RequestAnimDict(animDict)
                    while not HasAnimDictLoaded(animDict) do
                        Wait(10)
                    end

                    -- Play animation
                    TaskPlayAnim(playerPed, animDict, animName, 8.0, -8.0, -1, 49, 0, false, false, false)

                    if lib.progressBar({
                        duration = 2000,
                        label = 'Talking to ' .. (shop.label or 'shop') .. '...',
                        useWhileDead = false,
                        canCancel = true,
                        disable = {
                            car = true,
                        },
                        disableMovement = true  -- Disable movement during progress
                    }) then
                        ClearPedTasks(playerPed) -- Stop animation after completion
                        lib.showContext('shop_menu_' .. shopIndex)
                    else
                        ClearPedTasks(playerPed) -- Stop animation if canceled
                        print('Action cancelled')
                    end
                end
            }
        })
    elseif shop.useOxLibTextUI then
        -- Show TextUI message with same interaction as ox_target
        exports['ox_lib']:showTextUI('Press E to interact with ' .. (shop.label or 'Shop'))

        -- Wait for the player to press E to start interaction
        local playerPed = PlayerPedId()
        local interactionTriggered = false

        -- Show TextUI for interaction prompt and handle action when the player presses E
        while true do
            Wait(0)
            local pedCoords = GetEntityCoords(ped)
            local playerCoords = GetEntityCoords(playerPed)
            local dist = Vdist(pedCoords.x, pedCoords.y, pedCoords.z, playerCoords.x, playerCoords.y, playerCoords.z)
            
            if dist < 2.0 then
                if not interactionTriggered then
                    if IsControlJustPressed(0, 38) then  -- E key
                        interactionTriggered = true

                        -- Play animation and show progress bar
                        RequestAnimDict('mp_common')
                        while not HasAnimDictLoaded('mp_common') do
                            Wait(10)
                        end
                        TaskPlayAnim(playerPed, 'mp_common', 'givetake1_a', 8.0, -8.0, -1, 49, 0, false, false, false)

                        if lib.progressBar({
                            duration = 2000,
                            label = 'Talking to ' .. (shop.label or 'shop') .. '...',
                            useWhileDead = false,
                            canCancel = true,
                            disableMovement = true -- Disable movement during progress
                        }) then
                            ClearPedTasks(playerPed)
                            lib.showContext('shop_menu_' .. shopIndex)
                        else
                            ClearPedTasks(playerPed)
                            print('Action cancelled')
                        end
                    end
                end
            elseif dist > 2.0 then
                if interactionTriggered then
                    exports['ox_lib']:hideTextUI()  -- Hide the TextUI when player moves away
                    interactionTriggered = false
                end
            end
        end
    end
end

local Locales = {}

-- Load localization
function _U(entry, ...)
    local lang = Locales[Config.Locale] or {}
    return (lang[entry] or entry):format(...)

end

Citizen.CreateThread(function()
    for index, shop in ipairs(Config.Shops) do
        createShopMenu(index)
        spawnShopNPC(index)
    end
end)