ESX = exports.es_extended:getSharedObject()

RegisterNetEvent('amo_buy:item')
AddEventHandler('amo_buy:item', function(itemName, totalCost, quantity)
    local xPlayer = ESX.GetPlayerFromId(source)
    
    -- Check if the player has enough money
    if xPlayer.getMoney() >= totalCost then
        -- Deduct the money
        xPlayer.removeMoney(totalCost)

        -- Add the required number of items to the inventory
        xPlayer.addInventoryItem(itemName, quantity)

        -- Send a message to the player
        TriggerClientEvent('esx:showNotification', source, 'You bought ' .. quantity .. 'x ' .. itemName .. ' for $' .. totalCost)
    else
        TriggerClientEvent('esx:showNotification', source, 'You don\'t have enough money')
    end
end)

